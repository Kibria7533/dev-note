# ADD_PACKAGES
Uses apt-get to install a list of packages in the system
If a package needs customization, should be done outside (in another rol)
 